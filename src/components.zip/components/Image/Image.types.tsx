// src/components/HeroImage/Image.types.ts
export interface ImageProps {
    src?: string;
    alt?: string;
    placeholder?: string;
    visible?: boolean;
}
 