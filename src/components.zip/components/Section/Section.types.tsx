export interface SectionProps {
    disabled?: boolean;
    disabledBgColor?: string;
    visible?: boolean;
    children: React.ReactNode;
  }
  