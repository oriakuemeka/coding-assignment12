export { default } from './Text';

