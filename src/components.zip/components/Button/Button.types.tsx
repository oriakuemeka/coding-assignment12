export interface ButtonProps {
    disabled?: boolean;
    label?: string;
    visible?: boolean;
    disabledBackgroundColor?: string;
  }
  