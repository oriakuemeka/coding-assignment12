// Card.types.ts
export interface CardProps {
    imageUrl: string;
    name: string;
    email: string;
    isPrimary?: boolean;
    isDisabled?: boolean;
  }
  